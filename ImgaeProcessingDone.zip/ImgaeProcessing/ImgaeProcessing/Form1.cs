﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using System.Drawing;

namespace ImgaeProcessing
{
    public partial class Form1 : Form
    {
        Bitmap bitma;
        public Form1()
        {
            InitializeComponent();

        }
 
        String imageLocation = "";
        private void button1_Click(object sender, EventArgs e)
        {
           
            try{
                OpenFileDialog dialog = new OpenFileDialog();
        
                dialog=new OpenFileDialog();
                dialog.Filter="Jpg files(*.bmp,*.jpg)|*.jpg|Png Files(*.png)|*.png|All Files(*.*)|*.*";
           

            if(dialog.ShowDialog()==DialogResult.OK)
            {
                this.picOrig.Image = new Bitmap(dialog.FileName);
               // imageLocation=dialog.FileName;
                picOrig.ImageLocation=imageLocation;
                picOrig.SizeMode = PictureBoxSizeMode.StretchImage;
               
               
              
            }
               }
            catch(Exception){
                MessageBox.Show("An Error Occured","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);

            }

        }

        private void image1_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
//            image2.Show = image1;


        }


        private void button2_Click(object sender, EventArgs e)
        {
            try {
               
                
            Bitmap copy = new Bitmap((Bitmap)this.picOrig.Image);
            Rectangle r = new Rectangle(0, 0, copy.Width, copy.Height);
            using (Graphics g = Graphics.FromImage(copy)) {
            using (Brush cloud_brush = new SolidBrush(Color.FromArgb(128, Color.White))) {
            g.FillRectangle(cloud_brush, r);
    }
}

                
                this.picRes.Image = copy;
            this.picRes.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            catch(Exception)
            {
                MessageBox.Show("First Add Image", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
  
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Bitmap copBo = new Bitmap((Bitmap)this.picOrig.Image);
                using (Graphics g = Graphics.FromImage(copBo))
                {
                    g.DrawRectangle(new Pen(Brushes.Red, 25), new Rectangle(0, 0, copBo.Width, copBo.Height));
                }
                this.picBor.Image = copBo;
                picBor.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            catch (Exception)
            {
                MessageBox.Show("First Add Image", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            // bitmap.Save(@"C:\avatar63New.jpg");
        }

      

        


    }
}
